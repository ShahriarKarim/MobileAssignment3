package com.example.assignment3mobile

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
