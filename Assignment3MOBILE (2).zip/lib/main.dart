import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'MealPlanScreen.dart'; //importing all of the classes
import 'DatabaseHelper.dart'; //importing the database class
import 'food_item.dart';
import 'meal_plan.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'FlutterCaloriesAPP',
      theme: ThemeData(
        primarySwatch: Colors.red,
      ),
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  DateTime _selectedDate = DateTime.now();
  MealPlan? _queriedMealPlan;
  List<FoodItem> _mealPlanFoodItems = [];
  int _targetCalories = 0; // Added target calories variable
  TextEditingController _targetCaloriesController =
      TextEditingController(); // Controller for target calories

  Future<void> _queryMealPlan() async {
    MealPlan? mealPlan = await DatabaseHelper.getMealPlanByDate(_selectedDate);
    if (mealPlan != null) {
      List<FoodItem> foodItems =
          await DatabaseHelper.getFoodItemsByIds(mealPlan.foodItemIds);
      setState(() {
        _queriedMealPlan = mealPlan;
        _mealPlanFoodItems = foodItems;
      });
    } else {
      setState(() {
        _queriedMealPlan = null;
        _mealPlanFoodItems = [];
      });
    }
  }

  void _openMealPlanScreen() async {
    final selectedFoodItems = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => MealPlanScreen(),
      ),
    );
    if (selectedFoodItems != null) {
      setState(() {
        _targetCaloriesController.text = ''; // set target cal to 0 initial obv
        _targetCalories = 0; // Clear it for next inp
        _queriedMealPlan = null;
        _mealPlanFoodItems = selectedFoodItems; // Selected pair foods
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('FlutterCaloriesAPP'),
      ),
      body: Center(
        // Center the content in the middle of the screen
        child: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.all(8.0),
            child: Column(
              mainAxisAlignment:
                  MainAxisAlignment.center, // Center-align the column children
              children: <Widget>[
                // Other buttons and functionalities
                TextField(
                  controller: _targetCaloriesController,
                  decoration: InputDecoration(
                    labelText: 'Enter target calories per day',
                    border: OutlineInputBorder(),
                  ),
                  keyboardType: TextInputType.number,
                  onSubmitted: (value) {
                    setState(() {
                      _targetCalories = int.tryParse(value) ?? 0;
                    });
                  },
                ),
                SizedBox(height: 20),
                ElevatedButton(
                  onPressed: () async {
                    final DateTime? picked = await showDatePicker(
                      context: context,
                      initialDate: _selectedDate,
                      firstDate: DateTime(2000),
                      lastDate: DateTime(2100),
                    );
                    if (picked != null && picked != _selectedDate) {
                      setState(() {
                        _selectedDate = picked;
                      });
                    }
                  },
                  child: Text('Select Date'),
                ),
                SizedBox(height: 20),
                ElevatedButton(
                  onPressed: _openMealPlanScreen, // Open MealPlanScreen
                  child: Text('Create Meal Plan'),
                ),
                Divider(),
                ElevatedButton(
                  onPressed: _queryMealPlan,
                  child: Text('Query Meal Plan'),
                ),
                if (_queriedMealPlan != null) ...[
                  Text(
                      "Meal Plan for ${DateFormat('yyyy-MM-dd').format(_selectedDate)}"),
                  ..._mealPlanFoodItems
                      .map((item) => ListTile(
                            title: Text(item.name),
                            subtitle: Text('${item.calories} calories'),
                          ))
                      .toList(),
                ] else ...[
                  Text(
                      "No meal plan found for this date ${DateFormat('yyyy-MM-dd').format(_selectedDate)}"),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}
