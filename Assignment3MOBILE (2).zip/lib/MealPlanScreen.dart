import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'DatabaseHelper.dart'; //importitng the DatabaseHelper file
import 'food_item.dart';
import 'meal_plan.dart'; //importing all of the library files

class MealPlanScreen extends StatefulWidget {
  @override
  _MealPlanScreenState createState() => _MealPlanScreenState();
}

class _MealPlanScreenState extends State<MealPlanScreen> {
  List<FoodItem> _availableFoodItems = [];
  Map<int, bool> _selectedFoodItemIds = {};
  DateTime _selectedDate = DateTime.now();
  int _targetCalories = 0;
  final TextEditingController _targetCaloriesController =
      TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadFoodItems();
  }

  Future<void> _loadFoodItems() async {
    var foodItems = await DatabaseHelper.getFoodItems();
    setState(() {
      _availableFoodItems = foodItems;
      _selectedFoodItemIds = {for (var item in foodItems) item.id!: false};
    });
  }

  void _onFoodItemSelected(int id, bool isSelected) {
    if (isSelected) {
      int currentCalories = _availableFoodItems
          .where((item) => _selectedFoodItemIds[item.id!] == true)
          .fold(0, (total, current) => total + current.calories);
      if (currentCalories +
              _availableFoodItems
                  .firstWhere((item) => item.id == id)
                  .calories <=
          _targetCalories) {
        setState(() {
          _selectedFoodItemIds[id] = true;
        });
      }
    } else {
      setState(() {
        _selectedFoodItemIds[id] = false;
      });
    }
  }

  Future<void> _saveMealPlan() async {
    List<int> selectedFoodItems = _selectedFoodItemIds.entries
        .where((entry) => entry.value == true)
        .map((entry) => entry.key)
        .toList();
    MealPlan mealPlan =
        MealPlan(date: _selectedDate, foodItemIds: selectedFoodItems);
    await DatabaseHelper.insertMealPlan(mealPlan);
    // You might want to add a confirmation message or handle errors
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Create Meal Plan'),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(8.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              TextField(
                controller: _targetCaloriesController,
                decoration: InputDecoration(labelText: 'Target Calories'),
                keyboardType: TextInputType.number,
                onSubmitted: (value) {
                  setState(() {
                    _targetCalories = int.parse(value);
                  });
                },
              ),
              SizedBox(height: 10),
              ElevatedButton(
                onPressed: () async {
                  final DateTime? picked = await showDatePicker(
                    context: context,
                    initialDate: _selectedDate,
                    firstDate: DateTime(2000),
                    lastDate: DateTime(2100),
                  );
                  if (picked != null) {
                    setState(() {
                      _selectedDate = picked;
                    });
                  }
                },
                child: Text('Select Date'),
              ),
              SizedBox(height: 10),
              Text('Select Food Items:',
                  style: TextStyle(fontWeight: FontWeight.bold)),
              SizedBox(height: 10),
              ..._availableFoodItems.map((foodItem) {
                return CheckboxListTile(
                  title: Text(foodItem.name),
                  subtitle: Text('${foodItem.calories} calories'),
                  value: _selectedFoodItemIds[foodItem.id] ?? false,
                  onChanged: (bool? value) {
                    _onFoodItemSelected(foodItem.id!, value ?? false);
                  },
                );
              }).toList(),
              ElevatedButton(
                onPressed: _saveMealPlan,
                child: Text('Save Meal Plan'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
