class MealPlan {
  final DateTime date;
  final List<int> foodItemIds; //which is the food calorie pairs

  MealPlan({required this.date, required this.foodItemIds});

  Map<String, dynamic> toMap() {
    return {
      'date': date.toIso8601String(),
      'foodItemIds': foodItemIds.join(','),
    };
  }

  static MealPlan fromMap(Map<String, dynamic> map) {
    return MealPlan(
      date: DateTime.parse(map['date']),
      foodItemIds:
          map['foodItemIds'].split(',').map((id) => int.parse(id)).toList(),
    );
  }
}
