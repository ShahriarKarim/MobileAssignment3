import 'package:flutter/material.dart';
import 'food_item.dart'; //importing all of the library files
import 'DatabaseHelper.dart'; // Importing the databaseHelper class

class FoodCaloriePairs extends StatefulWidget {
  @override
  _FoodCaloriePairsState createState() => _FoodCaloriePairsState();
}

class _FoodCaloriePairsState extends State<FoodCaloriePairs> {
  List<FoodItem> _foodItems = [];

  @override
  void initState() {
    super.initState();
    _loadFoodItems();
  }

  Future<void> _loadFoodItems() async {
    // geting the list of the 20 calorie pairs from db
    List<FoodItem> foodItems = await DatabaseHelper.getFoodItems();

    setState(() {
      _foodItems = foodItems;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Food and Calorie Pairs'),
      ),
      body: ListView.builder(
        itemCount: _foodItems.length,
        itemBuilder: (context, index) {
          final foodItem = _foodItems[index];
          return ListTile(
            title: Text(foodItem.name),
            subtitle: Text('${foodItem.calories} calories'),
          );
        },
      ),
    );
  }
}
