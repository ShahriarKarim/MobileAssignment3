import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'food_item.dart'; //importing all of the library files
import 'meal_plan.dart';
import 'package:intl/intl.dart';

class DatabaseHelper {
  static Future<Database> getDatabase() async {
    final dbPath = await getDatabasesPath();
    return openDatabase(
      join(dbPath, 'calorie_calculator.db'),
      onCreate: (db, version) async {
        await db.execute(
          'CREATE TABLE foodItems(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, calories INTEGER)',
        );
        await db.execute(
          'CREATE TABLE mealPlans(id INTEGER PRIMARY KEY, date TEXT, foodItemIds TEXT)',
        );
        await initializeFoodItems(db); // Call to initialize food items
      },
      version: 1,
    );
  }

  static Future<void> initializeFoodItems(Database db) async {
    List<FoodItem> foodItems = [
      FoodItem(name: 'Apple', calories: 59),
      FoodItem(name: 'Banana', calories: 151),
      FoodItem(name: 'Grapes', calories: 100),
      FoodItem(name: 'Orange', calories: 53),
      FoodItem(name: 'Pear', calories: 82),
      FoodItem(name: 'Peach', calories: 67),
      FoodItem(name: 'Pineapple', calories: 82),
      FoodItem(name: 'Strawberry', calories: 53),
      FoodItem(name: 'Watermelon', calories: 50),
      FoodItem(name: 'Asparagus', calories: 27),
      FoodItem(name: 'Broccoli', calories: 45),
      FoodItem(name: 'Carrots', calories: 50),
      FoodItem(name: 'Cucumber', calories: 17),
      FoodItem(name: 'Eggplant', calories: 35),
      FoodItem(name: 'Lettuce', calories: 5),
      FoodItem(name: 'Tomato', calories: 22),
      FoodItem(name: 'Beef', calories: 142),
      FoodItem(name: 'Chicken', calories: 136),
      FoodItem(name: 'Tofu', calories: 86),
      FoodItem(name: 'Egg', calories: 78),
      FoodItem(name: 'Milk (2%)', calories: 122),
    ];

    for (var item in foodItems) {
      await db.insert(
        'foodItems',
        item.toMap(),
        conflictAlgorithm: ConflictAlgorithm.ignore,
      );
    }
  }

  static Future<void> insertFoodItem(FoodItem item) async {
    final db = await getDatabase();
    await db.insert(
      'foodItems',
      item.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  static Future<List<FoodItem>> getFoodItems() async {
    final db = await getDatabase();
    final List<Map<String, dynamic>> maps = await db.query('foodItems');

    return List.generate(maps.length, (i) {
      return FoodItem(
        id: maps[i]['id'],
        name: maps[i]['name'],
        calories: maps[i]['calories'],
      );
    });
  }

  static Future<void> updateFoodItem(FoodItem item) async {
    final db = await getDatabase();
    await db.update(
      'foodItems',
      item.toMap(),
      where: 'id = ?',
      whereArgs: [item.id],
    );
  }

  static Future<void> deleteFoodItem(int id) async {
    final db = await getDatabase();
    await db.delete(
      'foodItems',
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  static Future<void> insertMealPlan(MealPlan mealPlan) async {
    final db = await getDatabase();
    await db.insert(
      'mealPlans',
      {
        'date': mealPlan.date.toIso8601String(),
        'foodItemIds': mealPlan.foodItemIds.join(',')
      },
    );
  }

  static Future<MealPlan?> getMealPlanByDate(DateTime date) async {
    final db = await getDatabase();
    final List<Map<String, dynamic>> maps = await db.query(
      'mealPlans',
      where: 'date = ?',
      whereArgs: [DateFormat('yyyy-MM-dd').format(date)],
    );

    if (maps.isNotEmpty) {
      return MealPlan(
        date: DateTime.parse(maps.first['date']),
        foodItemIds: maps.first['foodItemIds']
            .split(',')
            .map((id) => int.parse(id))
            .toList(),
      );
    }
    return null;
  }

  static Future<List<FoodItem>> getFoodItemsByIds(List<int> ids) async {
    final db = await getDatabase();
    final List<Map<String, dynamic>> maps = await db.query(
      'foodItems',
      where: 'id IN (${ids.join(', ')})',
    );

    return List.generate(maps.length, (i) {
      return FoodItem(
        id: maps[i]['id'],
        name: maps[i]['name'],
        calories: maps[i]['calories'],
      );
    });
  }
}
